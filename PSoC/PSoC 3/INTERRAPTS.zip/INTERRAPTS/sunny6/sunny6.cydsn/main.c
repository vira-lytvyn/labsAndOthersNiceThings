/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

extern volatile uint8 toggle_flag;

void main()
{
	CyGlobalIntEnable;
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
	
	//Timer_1_Start();
	//Counter_1_Start();
	PWM_1_Start();
	isr_1_Start();
	LCD_Start();
	LCD_Position(0,5);
	LCD_PrintString("21.03.2013");
	LCD_Position(1,0);
	LCD_PrintString("Virusya");
	
    for(;;)
    {
        /* Place your application code here. */
		if (toggle_flag == 1){
			LED_Write(~LED_ReadDataReg());
			toggle_flag = 0;
		}
    }
}

/* [] END OF FILE */
