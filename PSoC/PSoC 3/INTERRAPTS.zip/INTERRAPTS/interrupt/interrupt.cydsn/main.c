
#include <device.h>

extern volatile uint8 toggle_flag;

void main()
{
 CYGlobalIntEnable;
 
 Timer_1_Start();
 isr_1_Start();
   LCD_Start();
   LCD_Position(0, 0);
   LCD_PrintString("Yaremkevych lab6");
   LCD_Position(1, 0);
   LCD_PrintString(" 18.03.2013");
 

    for(;;)
    {
       if ( toggle_flag == 1) 
	   {
	   LED1_Write(~LED1_ReadDataReg());
	   
	   toggle_flag = 0;
	   }
    }
}

