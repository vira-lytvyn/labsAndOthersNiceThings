#include <device.h>
uint8 curPos, oldPos;
void CapSense_DisplayState(void);
void main()
{
    LCD_Start();
    CapSense_CSD_Start();
    LCD_LoadCustomFonts(LCD_customFonts);    
    LCD_Position(0, 0);
    LCD_PrintString("Virusya");    
    CyGlobalIntEnable;    
    CapSense_CSD_InitializeAllBaselines();    
    for(;;)
    {     
        CapSense_CSD_UpdateEnabledBaselines();
        CapSense_CSD_ScanEnabledWidgets();        
        while (CapSense_CSD_IsBusy() != 0);        
        CapSense_DisplayState();
    }
}
void CapSense_DisplayState(void)
{
    if (CapSense_CSD_CheckIsWidgetActive(CapSense_CSD_B1__BTN))
    {
        LED3_Write(1);
    }
    else
    {
        LED3_Write(0);
    }
    if (CapSense_CSD_CheckIsWidgetActive(CapSense_CSD_B2__BTN ))
    {
        LED4_Write(1);
    }
    else
    {
        LED4_Write(0);
    }
    curPos = CapSense_CSD_GetCentroidPos(CapSense_CSD_SL1__LS);
    if (curPos == 0xFFFF)
    {
        curPos = 0;
    }
    if (curPos != oldPos)
    {
        oldPos = curPos;
        if (curPos != 0)
        {
            LCD_DrawHorizontalBG(0, 9, 6, curPos >> 1);
        }        
        LCD_Position(1, 10);
        LCD_PrintInt8(curPos);
    }
    else
        {
            LCD_DrawHorizontalBG(0, 9, 6, 0);
            LCD_Position(1, 10);
            LCD_PrintString("  ");
        }
}