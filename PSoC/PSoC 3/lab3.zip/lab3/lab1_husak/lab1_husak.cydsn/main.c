#include <device.h>

#define DMA_1_BYTES_PER_BURST 1
#define DMA_1_REQUEST_PER_BURST 1
#define DMA_1_SRC_BASE (CYDEV_SRAM_BASE)
#define DMA_1_DST_BASE (CYDEV_PERIPH_BASE)

uint8 DMA_1_Chan;
uint8 DMA_1_TD[1] ;

uint8 source[20];
uint8 sin[] = {102,118,132,143,151,153,151,143,132,118,102,86,72,61,53,51,53,60,72,86};
uint8 tri[] = {51,61,71,82,92,102,112,122,133,143,153,143,133,122,112,102,92,82,71,61};
uint8 rise[] = {56,61,66,71,77,82,87,92,97,102,107,112,117,122,128,133,138,143,148,153};

uint8 i; uint8 flag=1;

CY_ISR(InterruptHandler)
	{flag=0;}

void main()
{
  Clock_1_Start(); VDAC8_1_Start(); LCD_Char_1_Start(); UART_1_Start();
	
	  LCD_Char_1_Position(0,0); LCD_Char_1_PrintString("Virusya");
	

    DMA_1_Chan = DMA_1_DmaInitialize(DMA_1_BYTES_PER_BURST, DMA_1_REQUEST_PER_BURST,
	HI16(DMA_1_SRC_BASE), HI16(DMA_1_DST_BASE));
	DMA_1_TD[0] = CyDmaTdAllocate();
	CyDmaTdSetConfiguration(DMA_1_TD[0], 20, DMA_1_TD[0], TD_INC_SRC_ADR);
	CyDmaTdSetAddress(DMA_1_TD[0], LO16((uint32)source), LO16((uint32)VDAC8_1_Data_PTR));
	CyDmaChSetInitialTd(DMA_1_Chan, DMA_1_TD[0]);
	CyDmaChEnable(DMA_1_Chan, 1);
   
	CyGlobalIntEnable; isr_1_StartEx(InterruptHandler);
    
	for(;;)
	{
		LCD_Char_1_Position(1,5); LCD_Char_1_PrintString("   Sinusoid"); UART_1_PutString(" Sinusoid ");
		for (i=0; i<20; i++) source[i]=sin[i];
		flag=1; while (flag==1) {}
		
		LCD_Char_1_Position(1,5); LCD_Char_1_PrintString("   Triangle"); UART_1_PutString(" Triangle ");
		for (i=0; i<20; i++) source[i]=tri[i];
		flag=1; while (flag==1) {}
		
		LCD_Char_1_Position(1,5); LCD_Char_1_PrintString(" Rising Saw"); UART_1_PutString(" Rising Saw ");
		for (i=0; i<20; i++) source[i]=rise[i];
		flag=1; while (flag==1) {}
		
		LCD_Char_1_Position(1,5); LCD_Char_1_PrintString("Falling Saw"); UART_1_PutString(" Falling Saw ");
		for (i=20; i>0; i--) source[i]=rise[20-i];
		flag=1; while (flag==1) {} 
	}
}

