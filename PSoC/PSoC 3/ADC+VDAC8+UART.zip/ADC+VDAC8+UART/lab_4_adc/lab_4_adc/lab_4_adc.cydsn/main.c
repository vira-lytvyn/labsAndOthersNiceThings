/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>
#include <stdio.h>

char strVal[10];
float gScaleFactor = 0.0015;

void updateADC(void);

void main()
{
	CyGlobalIntEnable;
	
	LCD_Start();
	LCD_PrintString("Podibka I.");

	ADC_Start();
	ADC_StartConvert();
	
    for(;;)
    {
		updateADC();
    }
}

void updateADC(void) {
	if (ADC_IsEndConversion(ADC_RETURN_STATUS)) {
		uint16 output = ADC_GetResult16();
		float volts = ADC_CountsTo_Volts(output);
		
		LCD_Position(1, 0);
		LCD_PrintInt16(output);
		
		sprintf(strVal, "%5.4f", volts);
		LCD_Position(1, 7);
		LCD_PrintString(strVal);
		
	/*
		uint8 adcVal8;
		int16 adcVal16 = ADC_GetResult16();
		
		if (adcVal16 < 0) {
			adcVal16 = 0;
		} else if (adcVal16 > 0x3FFF) {
			adcVal16 = 0x3FFF;
		}
		
		adcVal8 = (uint8)(((uint16)adcVal16 >> 6) & 0xFFU);
		
		LCD_Position(1, 12);
		LCD_PrintNumber(adcVal8);
		*/
	}
}

/* [] END OF FILE */
