/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

#define DMA_BYTES_PER_BURST (1u)
#define DMA_REQUEST_PER_BURST (1u)
#define DMA_SRC_BASE (CYDEV_PERIPH_BASE)
#define DMA_DST_BASE (CYDEV_PERIPH_BASE)

void DMA_Config(void);

void main()
{  
    LCD_Start();
    VDAC_Start(); 
	ADC_Start();
	
	DMA_Config();
	
	ADC_StartConvert();
	
    LCD_Position(0,0);
    LCD_PrintString("Input:");
		
	LCD_Position(1,0);
	LCD_PrintString("Output:");

	for(;;)
    {	
		if (Status_Reg_Read())
		{
			LCD_Position(0,9);
        	LCD_PrintInt8(ADC_GetResult8());
		
			LCD_Position(1,9);
			LCD_PrintInt8(VDAC_Data);
		}			
    }
}

void DMA_Config(){
	uint8 DMA_Chan;
	uint8 DMA_TD[1] = 0;
	
	DMA_Chan = DMA_DmaInitialize(DMA_BYTES_PER_BURST, DMA_REQUEST_PER_BURST, HI16(DMA_SRC_BASE), HI16(DMA_DST_BASE));
	
	DMA_TD[0] = CyDmaTdAllocate();
	
	CyDmaTdSetConfiguration(DMA_TD[0], 1u, DMA_INVALID_TD, DMA__TD_TERMOUT_EN);
	
	CyDmaTdSetAddress(DMA_TD[0], LO16((uint32)ADC_DEC_SAMP_PTR), LO16((uint32)VDAC_Data_PTR));
	
	CyDmaChSetInitialTd(DMA_TD[0]);
	
	CyDmaChEnable(DMA_Chan, 1);
}

