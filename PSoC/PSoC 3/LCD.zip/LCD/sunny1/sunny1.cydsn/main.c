/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

void main()
{
	LCD_Start();
	
/*	LCD_Position(0, 0);
	LCD_PutChar(LCD_CUSTOM_0);
	
	LCD_Position(0, 1);
	LCD_PutChar(LCD_CUSTOM_1);
	
	LCD_Position(0, 2);
	LCD_PutChar(LCD_CUSTOM_2);
	
	LCD_Position(0, 3);
	LCD_PutChar(LCD_CUSTOM_3);
	
	LCD_Position(0, 4);
	LCD_PutChar(LCD_CUSTOM_4);
	
	LCD_Position(0, 5);
	LCD_PutChar(LCD_CUSTOM_5);
	
	LCD_Position(0, 6);
	LCD_PutChar(LCD_CUSTOM_6);
	
	LCD_Position(0, 7);
	LCD_PutChar(LCD_CUSTOM_7);*/
	
	
	//LCD_DrawHorizontalBG(0, 3, 10, 3);
	
	/*LCD_DrawHorizontalBG(0, 1, 2, LCD_CUSTOM_1);
	
	LCD_DrawHorizontalBG(0, 5, 2, LCD_CUSTOM_2);
	
	LCD_DrawHorizontalBG(0, 7, 2, LCD_CUSTOM_3);
	
	LCD_DrawHorizontalBG(0, 9, 2, LCD_CUSTOM_4);*/
	
	/*LCD_DrawVerticalBG(0, 0, 1, LCD_CUSTOM_7);
	LCD_DrawVerticalBG(0, 1, 1, LCD_CUSTOM_6);
	LCD_DrawVerticalBG(0, 2, 1, LCD_CUSTOM_5);
	LCD_DrawVerticalBG(0, 3, 1, LCD_CUSTOM_4);
	LCD_DrawVerticalBG(0, 4, 1, LCD_CUSTOM_3);
	LCD_DrawVerticalBG(0, 5, 1, LCD_CUSTOM_2);
	LCD_DrawVerticalBG(0, 6, 1, LCD_CUSTOM_1);
	LCD_DrawVerticalBG(0, 7, 1, LCD_CUSTOM_0);
	LCD_DrawVerticalBG(0, 8, 1, LCD_CUSTOM_0);
	LCD_DrawVerticalBG(0, 9, 1, LCD_CUSTOM_1);
	LCD_DrawVerticalBG(0, 10, 1, LCD_CUSTOM_2);
	LCD_DrawVerticalBG(0, 11, 1, LCD_CUSTOM_3);
	LCD_DrawVerticalBG(0, 12, 1, LCD_CUSTOM_4);
	LCD_DrawVerticalBG(0, 13, 1, LCD_CUSTOM_5);
	LCD_DrawVerticalBG(0, 14, 1, LCD_CUSTOM_6);
	LCD_DrawVerticalBG(0, 15, 1, LCD_CUSTOM_7);*/

	LCD_Position (0, 0);	
	LCD_PrintInt8(7);
	
	LCD_Position (0, 3);
	LCD_PrintNumber(700);
	
	LCD_Position (0, 7);
	LCD_PrintInt16(700);
    
    LCD_Position (0, 12);
    LCD_PrintNumber(5.35);
	
	LCD_Position(1, 0);
	LCD_PrintString("Lytvyn 15.02.2013");

    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
