/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

void main()
{
	LCD_Start();
	
	LCD_Position(0, 0);
	LCD_PutChar(LCD_CUSTOM_0);
	
	LCD_Position(0, 1);
	LCD_PutChar(LCD_CUSTOM_1);
	
	LCD_Position(0, 2);
	LCD_PutChar(LCD_CUSTOM_2);
	
	LCD_Position(0, 3);
	LCD_PutChar(LCD_CUSTOM_3);
	
	LCD_Position(0, 4);
	LCD_PutChar(LCD_CUSTOM_4);
	
	LCD_Position(0, 5);
	LCD_PutChar(LCD_CUSTOM_5);
	
	LCD_Position(0, 6);
	LCD_PutChar(LCD_CUSTOM_6);
	
	LCD_Position(0, 7);
	LCD_PutChar(LCD_CUSTOM_7);
	
	LCD_Position(1, 0);
	LCD_PrintString("Lab2 21.02.13");
	
	//PWM_Start();
	
    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
