/*******************************************************************************
* File Name: IDAC_Output.h  
* Version 1.80
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_IDAC_Output_H) /* Pins IDAC_Output_H */
#define CY_PINS_IDAC_Output_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "IDAC_Output_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    IDAC_Output_Write(uint8 value) ;
void    IDAC_Output_SetDriveMode(uint8 mode) ;
uint8   IDAC_Output_ReadDataReg(void) ;
uint8   IDAC_Output_Read(void) ;
uint8   IDAC_Output_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define IDAC_Output_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define IDAC_Output_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define IDAC_Output_DM_RES_UP          PIN_DM_RES_UP
#define IDAC_Output_DM_RES_DWN         PIN_DM_RES_DWN
#define IDAC_Output_DM_OD_LO           PIN_DM_OD_LO
#define IDAC_Output_DM_OD_HI           PIN_DM_OD_HI
#define IDAC_Output_DM_STRONG          PIN_DM_STRONG
#define IDAC_Output_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define IDAC_Output_MASK               IDAC_Output__MASK
#define IDAC_Output_SHIFT              IDAC_Output__SHIFT
#define IDAC_Output_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define IDAC_Output_PS                     (* (reg8 *) IDAC_Output__PS)
/* Data Register */
#define IDAC_Output_DR                     (* (reg8 *) IDAC_Output__DR)
/* Port Number */
#define IDAC_Output_PRT_NUM                (* (reg8 *) IDAC_Output__PRT) 
/* Connect to Analog Globals */                                                  
#define IDAC_Output_AG                     (* (reg8 *) IDAC_Output__AG)                       
/* Analog MUX bux enable */
#define IDAC_Output_AMUX                   (* (reg8 *) IDAC_Output__AMUX) 
/* Bidirectional Enable */                                                        
#define IDAC_Output_BIE                    (* (reg8 *) IDAC_Output__BIE)
/* Bit-mask for Aliased Register Access */
#define IDAC_Output_BIT_MASK               (* (reg8 *) IDAC_Output__BIT_MASK)
/* Bypass Enable */
#define IDAC_Output_BYP                    (* (reg8 *) IDAC_Output__BYP)
/* Port wide control signals */                                                   
#define IDAC_Output_CTL                    (* (reg8 *) IDAC_Output__CTL)
/* Drive Modes */
#define IDAC_Output_DM0                    (* (reg8 *) IDAC_Output__DM0) 
#define IDAC_Output_DM1                    (* (reg8 *) IDAC_Output__DM1)
#define IDAC_Output_DM2                    (* (reg8 *) IDAC_Output__DM2) 
/* Input Buffer Disable Override */
#define IDAC_Output_INP_DIS                (* (reg8 *) IDAC_Output__INP_DIS)
/* LCD Common or Segment Drive */
#define IDAC_Output_LCD_COM_SEG            (* (reg8 *) IDAC_Output__LCD_COM_SEG)
/* Enable Segment LCD */
#define IDAC_Output_LCD_EN                 (* (reg8 *) IDAC_Output__LCD_EN)
/* Slew Rate Control */
#define IDAC_Output_SLW                    (* (reg8 *) IDAC_Output__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define IDAC_Output_PRTDSI__CAPS_SEL       (* (reg8 *) IDAC_Output__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define IDAC_Output_PRTDSI__DBL_SYNC_IN    (* (reg8 *) IDAC_Output__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define IDAC_Output_PRTDSI__OE_SEL0        (* (reg8 *) IDAC_Output__PRTDSI__OE_SEL0) 
#define IDAC_Output_PRTDSI__OE_SEL1        (* (reg8 *) IDAC_Output__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define IDAC_Output_PRTDSI__OUT_SEL0       (* (reg8 *) IDAC_Output__PRTDSI__OUT_SEL0) 
#define IDAC_Output_PRTDSI__OUT_SEL1       (* (reg8 *) IDAC_Output__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define IDAC_Output_PRTDSI__SYNC_OUT       (* (reg8 *) IDAC_Output__PRTDSI__SYNC_OUT) 


#if defined(IDAC_Output__INTSTAT)  /* Interrupt Registers */

    #define IDAC_Output_INTSTAT                (* (reg8 *) IDAC_Output__INTSTAT)
    #define IDAC_Output_SNAP                   (* (reg8 *) IDAC_Output__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins IDAC_Output_H */


/* [] END OF FILE */
