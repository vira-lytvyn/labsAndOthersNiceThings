/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>

void main()
{
    LCD_Start();
	LCD_ClearDisplay();
	
	IDAC8_Start();
	IDAC8_SetRange(IDAC8_RANGE_2mA);
	IDAC8_SetValue(1);
	
	LCD_Position(0,0); 
    LCD_PrintString("Virusya");
	
    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
    for(;;)
    {
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
