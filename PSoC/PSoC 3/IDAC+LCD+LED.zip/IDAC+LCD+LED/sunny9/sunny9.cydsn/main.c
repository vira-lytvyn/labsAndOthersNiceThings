/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>
int i, j;
int val = 1;
void main()
{
	LCD_Start();
	LCD_ClearDisplay();
	
	ADC_Start();
	ADC_StartConvert();
	
	val = 0;
	
	IDAC8_Start();
	IDAC8_SetRange(IDAC8_RANGE_2mA);
	//IDAC8_SetValue(val);
			
	LCD_Position(0,0); 
    LCD_PrintString("Virusya");
		
    /* Place your initialization/startup code here (e.g. MyInst_Start()) */

    /* CyGlobalIntEnable; */ /* Uncomment this line to enable global interrupts. */
	LCD_Position(1,0);
	LCD_PrintString("Output:");

    for(;;)
    {
		for (i = 0; i < 5; i++){
			IDAC8_SetValue(val +=10);			
		}
		for (i = 4; i < 13; i++){
			IDAC8_SetValue(val+=25);	
		}	
		LCD_Position(1,9);
		LCD_PrintInt8(IDAC8_Data());
        /* Place your application code here. */
    }
}

/* [] END OF FILE */
