/*******************************************************************************
* File Name: OutputSig.h  
* Version 1.80
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_OutputSig_H) /* Pins OutputSig_H */
#define CY_PINS_OutputSig_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "OutputSig_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    OutputSig_Write(uint8 value) ;
void    OutputSig_SetDriveMode(uint8 mode) ;
uint8   OutputSig_ReadDataReg(void) ;
uint8   OutputSig_Read(void) ;
uint8   OutputSig_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define OutputSig_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define OutputSig_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define OutputSig_DM_RES_UP          PIN_DM_RES_UP
#define OutputSig_DM_RES_DWN         PIN_DM_RES_DWN
#define OutputSig_DM_OD_LO           PIN_DM_OD_LO
#define OutputSig_DM_OD_HI           PIN_DM_OD_HI
#define OutputSig_DM_STRONG          PIN_DM_STRONG
#define OutputSig_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define OutputSig_MASK               OutputSig__MASK
#define OutputSig_SHIFT              OutputSig__SHIFT
#define OutputSig_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define OutputSig_PS                     (* (reg8 *) OutputSig__PS)
/* Data Register */
#define OutputSig_DR                     (* (reg8 *) OutputSig__DR)
/* Port Number */
#define OutputSig_PRT_NUM                (* (reg8 *) OutputSig__PRT) 
/* Connect to Analog Globals */                                                  
#define OutputSig_AG                     (* (reg8 *) OutputSig__AG)                       
/* Analog MUX bux enable */
#define OutputSig_AMUX                   (* (reg8 *) OutputSig__AMUX) 
/* Bidirectional Enable */                                                        
#define OutputSig_BIE                    (* (reg8 *) OutputSig__BIE)
/* Bit-mask for Aliased Register Access */
#define OutputSig_BIT_MASK               (* (reg8 *) OutputSig__BIT_MASK)
/* Bypass Enable */
#define OutputSig_BYP                    (* (reg8 *) OutputSig__BYP)
/* Port wide control signals */                                                   
#define OutputSig_CTL                    (* (reg8 *) OutputSig__CTL)
/* Drive Modes */
#define OutputSig_DM0                    (* (reg8 *) OutputSig__DM0) 
#define OutputSig_DM1                    (* (reg8 *) OutputSig__DM1)
#define OutputSig_DM2                    (* (reg8 *) OutputSig__DM2) 
/* Input Buffer Disable Override */
#define OutputSig_INP_DIS                (* (reg8 *) OutputSig__INP_DIS)
/* LCD Common or Segment Drive */
#define OutputSig_LCD_COM_SEG            (* (reg8 *) OutputSig__LCD_COM_SEG)
/* Enable Segment LCD */
#define OutputSig_LCD_EN                 (* (reg8 *) OutputSig__LCD_EN)
/* Slew Rate Control */
#define OutputSig_SLW                    (* (reg8 *) OutputSig__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define OutputSig_PRTDSI__CAPS_SEL       (* (reg8 *) OutputSig__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define OutputSig_PRTDSI__DBL_SYNC_IN    (* (reg8 *) OutputSig__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define OutputSig_PRTDSI__OE_SEL0        (* (reg8 *) OutputSig__PRTDSI__OE_SEL0) 
#define OutputSig_PRTDSI__OE_SEL1        (* (reg8 *) OutputSig__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define OutputSig_PRTDSI__OUT_SEL0       (* (reg8 *) OutputSig__PRTDSI__OUT_SEL0) 
#define OutputSig_PRTDSI__OUT_SEL1       (* (reg8 *) OutputSig__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define OutputSig_PRTDSI__SYNC_OUT       (* (reg8 *) OutputSig__PRTDSI__SYNC_OUT) 


#if defined(OutputSig__INTSTAT)  /* Interrupt Registers */

    #define OutputSig_INTSTAT                (* (reg8 *) OutputSig__INTSTAT)
    #define OutputSig_SNAP                   (* (reg8 *) OutputSig__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins OutputSig_H */


/* [] END OF FILE */
