/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include <device.h>
#include <stdio.h>
uint8 i;
float f;
uint8 string[16];
char s[20];
uint8 source[20];
uint8 sin[] = {127, 166, 201,  229,  247,  253,  247,  229,  201,  166,
	  127,  87,  52,  24,  6,  0,  6,  24,  52,  87};
void main()
{
   CyGlobalIntEnable;   
    LCD_Start();
    VDAC_Start(); 
	ADC_Start();
    LCD_Position(0,0);
    LCD_PrintString("Hello!!!");
	i = 0;
    UART_Start();
	for(;;)//i=0; i<20; i++)
    {	
		source[i] = sin[i];
	    VDAC_SetValue(source[i]);
		i++;
		if (i>=20) {i=0;}
		
		LCD_Position(1,12);
        LCD_PrintString("V");
		LCD_Position(1,0);
		LCD_PrintString("U=");
        LCD_Position(1,3);
        ADC_StartConvert();
        ADC_IsEndConversion(ADC_WAIT_FOR_RESULT);
        f = ADC_CountsTo_Volts(ADC_GetResult32());//*1000;
        sprintf(string,"%4.4f",f);
        LCD_PrintString(string);
        //sprintf(s,"%1d",(int)(source[i]));
		UART_PutString(string);
		UART_PutString("\n\r");
		CyDelay(300);
    }
}


