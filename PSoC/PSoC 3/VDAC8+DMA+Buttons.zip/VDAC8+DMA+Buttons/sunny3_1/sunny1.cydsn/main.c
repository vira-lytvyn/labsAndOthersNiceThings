#include <device.h>

#define DMA_BYTES_PER_BURST 1
#define DMA_REQUEST_PER_BURST 1
#define DMA_SRC_BASE (CYDEV_SRAM_BASE)
#define DMA_DST_BASE (CYDEV_PERIPH_BASE)

uint8 DMA_Chan;
uint8 DMA_TD[1] ;

uint8 source[20];
uint8 sin[] = {127, 166, 201,  229,  247,  253,  247,  229,  201,  166,
				127,  87,  52,  24,  6,  0,  6,  24,  52,  87};

uint8 i = 0;

void main()
{
	LCD_Start();
	Clock_Start();
	
	LCD_Position(0, 0);
	LCD_PutChar(LCD_CUSTOM_0);
	
	LCD_Position(0, 1);
	LCD_PutChar(LCD_CUSTOM_1);
	
	LCD_Position(0, 2);
	LCD_PutChar(LCD_CUSTOM_2);
	
	LCD_Position(0, 3);
	LCD_PutChar(LCD_CUSTOM_3);
	
	LCD_Position(0, 4);
	LCD_PutChar(LCD_CUSTOM_4);
	
	LCD_Position(0, 5);
	LCD_PutChar(LCD_CUSTOM_5);
	
	LCD_Position(0, 6);
	LCD_PutChar(LCD_CUSTOM_6);
	
	LCD_Position(0, 7);
	LCD_PutChar(LCD_CUSTOM_7);
	
	VDAC8_Start();
	
	LCD_Position(1, 3);
	LCD_PrintString("   Sinusoida");
	
	DMA_Chan = DMA_DmaInitialize(DMA_BYTES_PER_BURST, DMA_REQUEST_PER_BURST,
	HI16(DMA_SRC_BASE), HI16(DMA_DST_BASE));
	DMA_TD[0] = CyDmaTdAllocate();
	CyDmaTdSetConfiguration(DMA_TD[0], 20, DMA_TD[0], TD_INC_SRC_ADR);
	CyDmaTdSetAddress(DMA_TD[0], LO16((uint32)source), LO16((uint32)VDAC8_Data_PTR));
	CyDmaChSetInitialTd(DMA_Chan, DMA_TD[0]);
	CyDmaChEnable(DMA_Chan, 1);
		
    for(;;)
    {        
		i+=1;		
		if	(i>19) i=0;
		VDAC8_SetValue(sin[i]);
		source[i]=sin[i];
		//for (i=0; i<20; i++) source[i]=sin[i];
    }
}

/* [] END OF FILE */
