/*******************************************************************************
* File Name: Button_Pin_2_O.h  
* Version 1.80
*
* Description:
*  This file containts Control Register function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_Button_Pin_2_O_H) /* Pins Button_Pin_2_O_H */
#define CY_PINS_Button_Pin_2_O_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "Button_Pin_2_O_aliases.h"


/***************************************
*        Function Prototypes             
***************************************/    

void    Button_Pin_2_O_Write(uint8 value) ;
void    Button_Pin_2_O_SetDriveMode(uint8 mode) ;
uint8   Button_Pin_2_O_ReadDataReg(void) ;
uint8   Button_Pin_2_O_Read(void) ;
uint8   Button_Pin_2_O_ClearInterrupt(void) ;


/***************************************
*           API Constants        
***************************************/

/* Drive Modes */
#define Button_Pin_2_O_DM_ALG_HIZ         PIN_DM_ALG_HIZ
#define Button_Pin_2_O_DM_DIG_HIZ         PIN_DM_DIG_HIZ
#define Button_Pin_2_O_DM_RES_UP          PIN_DM_RES_UP
#define Button_Pin_2_O_DM_RES_DWN         PIN_DM_RES_DWN
#define Button_Pin_2_O_DM_OD_LO           PIN_DM_OD_LO
#define Button_Pin_2_O_DM_OD_HI           PIN_DM_OD_HI
#define Button_Pin_2_O_DM_STRONG          PIN_DM_STRONG
#define Button_Pin_2_O_DM_RES_UPDWN       PIN_DM_RES_UPDWN

/* Digital Port Constants */
#define Button_Pin_2_O_MASK               Button_Pin_2_O__MASK
#define Button_Pin_2_O_SHIFT              Button_Pin_2_O__SHIFT
#define Button_Pin_2_O_WIDTH              1u


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define Button_Pin_2_O_PS                     (* (reg8 *) Button_Pin_2_O__PS)
/* Data Register */
#define Button_Pin_2_O_DR                     (* (reg8 *) Button_Pin_2_O__DR)
/* Port Number */
#define Button_Pin_2_O_PRT_NUM                (* (reg8 *) Button_Pin_2_O__PRT) 
/* Connect to Analog Globals */                                                  
#define Button_Pin_2_O_AG                     (* (reg8 *) Button_Pin_2_O__AG)                       
/* Analog MUX bux enable */
#define Button_Pin_2_O_AMUX                   (* (reg8 *) Button_Pin_2_O__AMUX) 
/* Bidirectional Enable */                                                        
#define Button_Pin_2_O_BIE                    (* (reg8 *) Button_Pin_2_O__BIE)
/* Bit-mask for Aliased Register Access */
#define Button_Pin_2_O_BIT_MASK               (* (reg8 *) Button_Pin_2_O__BIT_MASK)
/* Bypass Enable */
#define Button_Pin_2_O_BYP                    (* (reg8 *) Button_Pin_2_O__BYP)
/* Port wide control signals */                                                   
#define Button_Pin_2_O_CTL                    (* (reg8 *) Button_Pin_2_O__CTL)
/* Drive Modes */
#define Button_Pin_2_O_DM0                    (* (reg8 *) Button_Pin_2_O__DM0) 
#define Button_Pin_2_O_DM1                    (* (reg8 *) Button_Pin_2_O__DM1)
#define Button_Pin_2_O_DM2                    (* (reg8 *) Button_Pin_2_O__DM2) 
/* Input Buffer Disable Override */
#define Button_Pin_2_O_INP_DIS                (* (reg8 *) Button_Pin_2_O__INP_DIS)
/* LCD Common or Segment Drive */
#define Button_Pin_2_O_LCD_COM_SEG            (* (reg8 *) Button_Pin_2_O__LCD_COM_SEG)
/* Enable Segment LCD */
#define Button_Pin_2_O_LCD_EN                 (* (reg8 *) Button_Pin_2_O__LCD_EN)
/* Slew Rate Control */
#define Button_Pin_2_O_SLW                    (* (reg8 *) Button_Pin_2_O__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define Button_Pin_2_O_PRTDSI__CAPS_SEL       (* (reg8 *) Button_Pin_2_O__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define Button_Pin_2_O_PRTDSI__DBL_SYNC_IN    (* (reg8 *) Button_Pin_2_O__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define Button_Pin_2_O_PRTDSI__OE_SEL0        (* (reg8 *) Button_Pin_2_O__PRTDSI__OE_SEL0) 
#define Button_Pin_2_O_PRTDSI__OE_SEL1        (* (reg8 *) Button_Pin_2_O__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define Button_Pin_2_O_PRTDSI__OUT_SEL0       (* (reg8 *) Button_Pin_2_O__PRTDSI__OUT_SEL0) 
#define Button_Pin_2_O_PRTDSI__OUT_SEL1       (* (reg8 *) Button_Pin_2_O__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define Button_Pin_2_O_PRTDSI__SYNC_OUT       (* (reg8 *) Button_Pin_2_O__PRTDSI__SYNC_OUT) 


#if defined(Button_Pin_2_O__INTSTAT)  /* Interrupt Registers */

    #define Button_Pin_2_O_INTSTAT                (* (reg8 *) Button_Pin_2_O__INTSTAT)
    #define Button_Pin_2_O_SNAP                   (* (reg8 *) Button_Pin_2_O__SNAP)

#endif /* Interrupt Registers */

#endif /* End Pins Button_Pin_2_O_H */


/* [] END OF FILE */
