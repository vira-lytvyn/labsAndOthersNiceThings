//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "stdlib.h" 

int d[20]={127, 166, 201,  229,  247,  253,  247,  229,  201,  166,
	  127,  87,  52,  24,  6,  0,  6,  24,  52,  87};
int i=0;

void vr1(void)
{
	i+=1;
	if	(i>19) i=0;
}

void main()
{
    LCD_1_Start();  
    M8C_EnableGInt;
	Counter16_1_EnableInt();
	DAC8_1_Start(DAC8_1_HIGHPOWER);         /* start the DAC8_1  */ 
    Counter16_1_Start();                   /* start the Counter24_1  */ 
	LCD_1_Position(0,0);
      LCD_1_PrCString("lab8 31.10.2012");
	  
	while(1) 
	 { 
	  DAC8_1_WriteBlind(d[i]);
	 }
}
