//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include <stdlib.h>
#include <math.h>

#define RREF 13000;

unsigned char bTempValue;

const unsigned WThermTable[ ] = {3468.2, 3355.4, 3246.9, 3142.7, 3042.6, 2946.3, 2853.6, 2764.6,
									 2678.9, 2596.4, 2517.0, 2440.6, 2366.9, 2296.0, 2227.7, 2161.8,
									 2098.3, 2037.1, 1978.0, 1921.5, 1866.2, 1813.2, 1762.0, 1712.6,
									 1664.9, 1618.8, 1574.3, 1531.3, 1489.7, 1449.5, 1410.7, 1373.2,
									 1336.8, 1301.6, 1267.6, 1234.7, 1202.9, 1172.0, 1142.2, 1113.2,
									 1085.2, 1058.1, 1031.8, 1006.3, 981.6, 957.6, 934.4, 911.9,
									 890.0, 868.9, 848.3, 828.3, 808.9, 790.1, 771.9, 754.1, 
									 736.9, 720.2, 703.9, 688.1, 672.8, 657.9, 643.4, 629.3,
									 615.6, 602.6, 589.2, 576.7, 564.3, 552.4, 540.8, 529.4,
									 518.4, 507.7, 497.2, 487.0, 477.1, 467.5, 458.1, 448.9, 
									 0};

int iV0;
int iV1;
int iV2;
long lRvalue;
char pTemp[12];
char *pResult;
int iStatus;


void CalculateR(void);
void main(void)
{
	InputAtten_Start(InputAtten_HIGHPOWER);
	InputAtten_GAIN_CR2 |= 0x18;	//connect REFLO to analog column 0
	Buffer_Start(Buffer_HIGHPOWER);
	Buffer_GAIN_CR2 |= 0x1c;		//connect REFHI to analog column 1
	
	LCD_Start();
	//LCD_Position(0, 0);
	//LCD_PrCString("Laboratorna 10");
	
	ADC_Start(ADC_HIGHPOWER);
	M8C_EnableGInt;
	
	while (1) {
		ADCMUX_InputSelect(ADCMUX_PORT0_5);
		ADC_GetSamples(1);
		while(ADC_fIsDataAvailable() == 0);
		iV0 = ADC_iClearFlagGetData();
		
		ADCMUX_InputSelect(ADCMUX_PORT0_1);
		ADC_GetSamples(1);
		while(ADC_fIsDataAvailable() == 0);
		iV1 = ADC_iClearFlagGetData();
		
		ADCMUX_InputSelect(ADCMUX_PORT0_3);
		ADC_GetSamples(1);
		while(ADC_fIsDataAvailable() == 0);
		iV2 = ADC_iClearFlagGetData();
		
		CalculateR();
		LCD_Position(0, 0);
		LCD_PrCString("R = ");
		LCD_Position(0, 4);
		ltoa(pTemp, lRvalue, 10);
		LCD_PrString(pTemp);
		for(bTempValue= 0;((unsigned)lRvalue)< WThermTable[bTempValue]; bTempValue++);
		LCD_Position(1, 0);
		LCD_PrCString("T = ");
		LCD_Position(1, 5);
		pResult = ftoa(bTempValue, &iStatus );
		//ltoa(pTemp, bTempValue, 10);
		LCD_PrString(pResult);
	}
}

void CalculateR(void) {
	if (iV0 <= iV1) {
		lRvalue = -1;
	} else if (iV1 <= iV2) {
		lRvalue = 0;
	} else {
		lRvalue = RREF;
		lRvalue *= (long)(iV1 - iV2);
		lRvalue += ((long)((iV0 - iV1) > 1));
		lRvalue /= (long)(iV0 - iV1);
	}
}