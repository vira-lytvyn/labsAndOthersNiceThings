//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules

void welcomeScreen(void);//Declaration of the function that prints Welcome String on Hyperterminal


void main(void)
{
	// M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts
	// Insert your main routine code here.
	    // Parameter pointer
    char *strPtr; 
    
LCD_Start();                              // Initialize LCD hardware
LCD_Position(0,4);                     // Position cursor @ row 0, col 4
LCD_PrCString("Vira Lytvyn");      // Print a constant "ROM" string
LCD_Position(1,2);                    // Position cursor @ row 1, col 2
LCD_PrCString("Lab 14");  // Print "RAM" based string.
// Initialize receiver/cmd buffer
UART_CmdReset(); 
//Turn on interrupts
M8C_EnableGInt ;
    //Enable RX interrupts
UART_IntCntl(UART_ENABLE_RX_INT);       
//set parity as zero and start the UART 
 UART_Start(UART_PARITY_NONE);            
 //Clear the screen in Hyper terminal window
 UART_PutChar(12); 
    
// Print welcome screen
welcomeScreen();
    
    while(1) {
        if (UART_bCmdCheck()) {                  // Wait for command Terminator
            if(strPtr = UART_szGetParam()) {     // More than delimiter?
                UART_CPutString("\n\rFound valid command\r\nCommand =>");
                UART_PutString(strPtr); // Print out command
                UART_CPutString("<\r\nParameters:\r\n");
                
                // loop on each parameter till a null pointer is returned
while(strPtr = UART_szGetParam()) { 
                    UART_CPutString(" <");
                    UART_PutString(strPtr); // Print each parameter
                    UART_CPutString(">\r\n");
                                                          }   
               }
//Reset command buffer and flags
            UART_CmdReset();

// Print Welcome String
            welcomeScreen();
        }
    }    

}

// Function to print the welcome screen
void welcomeScreen(void)
{
    UART_CPutString("\n\rWelcome to PSoC UART test program. V1.0");    
    UART_CPutString("\n\rEnter a command and some parameters (delimited by space) and press <ENTER>");
    UART_CPutString("\n\r   Eg:    foobar aa bbb cc      (MAX : 32 chars)");
    UART_CPutString("\n\r");
}

