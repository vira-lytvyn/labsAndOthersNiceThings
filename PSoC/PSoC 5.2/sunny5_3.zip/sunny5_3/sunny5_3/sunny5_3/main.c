//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "PSoCGPIOINT.h"// PsoC Interrupupt definitions for all pins of ports.
#include "PSoCDynamic.h"

int i = 1;
int gCount = 0;

void vr1(void)
{
	LoadConfig_blinkConfig();
	Counter16_BRed_Start();
}

void vr2(void)
{
	if (i == 1)
	{
		Counter16_3_Start();
		Counter16_1_Stop();
		Counter16_2_Stop();
		i = 0;
	} 
	else 
	{
		Counter16_1_Start();
		Counter16_2_Stop();
		Counter16_3_Stop();
		i = 1;
	}
	
}

void vr3(void)
{
	LoadConfig_blinkConfig();
	Counter16_BGreen_Start();
}

void interruptBlinkRed(void) 
{
	gCount++;
	if (gCount == 3) 
	{
		Counter16_BRed_Stop();
		UnloadConfig_blinkConfig();
		
		LoadConfig_mainConfig();
		Counter16_2_Start();
		Counter16_1_Stop();
		Counter16_3_Stop();
		
		gCount = 0;
	}
}

void interruptBlinkGreen(void) 
{
	gCount++;
	if (gCount == 3) 
	{
		Counter16_BGreen_Stop();
		UnloadConfig_blinkConfig();
		
		LoadConfig_mainConfig();
		Counter16_2_Start();
		Counter16_1_Stop();
		Counter16_3_Stop();
		
		gCount = 0;
	}
}

void main(void)
{
	char str[ ] = "Laboratorna 5_3";   
	LCD_1_Start();                      
	LCD_1_Position(0,3);              
	LCD_1_PrCString("15.10.2012");      
	LCD_1_Position(1,0);              
	LCD_1_PrString(str);

	Counter16_1_EnableInt();
	Counter16_2_EnableInt();
	Counter16_3_EnableInt();
	Counter16_BRed_EnableInt();
	Counter16_BGreen_EnableInt();
	M8C_EnableGInt;// Дозволити глобальні переривання
	
    Counter16_1_Start();
	Counter16_2_Stop();
	Counter16_3_Stop();
   
   while (1){
	}
}
