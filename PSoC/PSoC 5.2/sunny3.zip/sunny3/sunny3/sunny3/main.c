//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules

int ButtonState = 0;
int ButtonLastState = 0;

void main(void)
{
	// M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts
	// Insert your main routine code here.
	while (1)
	{
		if (PRT0DR & 0x01)
		{
			ButtonState = 0;
		}
		else
		{
			ButtonState = 1;
		}
		
		if ((ButtonState == 1) && (ButtonLastState == 0))
		{
			PWM8_1_Start();
		}
		if ((ButtonState == 0) && (ButtonLastState == 1))
		{
			PWM8_1_Stop();
		}
		
		ButtonLastState = ButtonState;
	}
}
