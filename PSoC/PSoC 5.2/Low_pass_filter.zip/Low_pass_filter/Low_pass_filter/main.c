//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules

int gIndex = 0;
int gValues[20] = {127, 166, 201, 229, 247, 253, 247, 229, 201, 166, 
					127, 87, 52, 24, 6, 0, 6, 24, 52, 87};

void counterInterrupt(void)
{
	Counter16_Start();
	gIndex++;
	if (gIndex > 19) {
		gIndex = 0;
	}
}

void main(void)
{
	 M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts
	 Counter16_EnableInt();
	 Counter16_Start();
	 
	 DAC8_Start(DAC8_HIGHPOWER);
	 DAC8_WriteBlind(253);
	 LPF2_Start(LPF2_HIGHPOWER);
	 
	 while (1) {
	 	DAC8_WriteBlind(gValues[gIndex]);
	 }
}
