//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "PSoCGPIOINT.h"

//BYTE SleepTimer_64_HZ = 0x08;
//BYTE SleepTimer_WAIT_RELOAD = 0x00;

char sleap[ ] = "Sleep Mode";
char active[ ] = "Danger!!!";

void welcomeScreen(void);//Declaration of the function that prints Welcome String on Hyperterminal

void getup(void)
{
	Danger_Start();//
	LCD_Position(0,0);              
	LCD_PrString(active);
}

void blink(void)
{
	Danger_Stop();	
	LCD_Position(1,0);              
	LCD_PrString(sleap);
	M8C_Sleep;
}

void main(void)
{	
	char *strPtr; 
	LCD_Start();                              // Initialize LCD hardware
	LCD_Position(0,0);                     // Position cursor @ row 0, col 4
	LCD_PrString(sleap);
	
	M8C_EnableGInt ;
	M8C_EnableIntMask (INT_MSK0, INT_MSK0_GPIO);
	
UART_CmdReset(); 
    //Enable RX interrupts
UART_IntCntl(UART_ENABLE_RX_INT);       
//set parity as zero and start the UART 
 UART_Start(UART_PARITY_NONE);            
 //Clear the screen in Hyper terminal window
 UART_PutChar(12); 
    
// Print welcome screen
	M8C_Sleep;
		
	while(1) {
        if (UART_bCmdCheck()) {                  // Wait for command Terminator
            if(strPtr = UART_szGetParam()) {     // More than delimiter?
                UART_CPutString("\n\rFound command to get up\r\nCommand =>");
                UART_PutString(strPtr); // Print out command
			}
	//Reset command buffer and flags
            UART_CmdReset();

	// Print Welcome String
            welcomeScreen();
        }
    } 		
}
void welcomeScreen(void)
{
    UART_CPutString("\n\rWelcome to PSoC UART test program. V1.0");    
    UART_CPutString("\n\rEnter any symbol to get system up and press <ENTER>");
    UART_CPutString("\n\r");
}