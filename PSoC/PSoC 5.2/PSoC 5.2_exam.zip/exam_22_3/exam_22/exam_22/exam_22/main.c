//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include "global.h"

//BYTE SleepTimer_64_HZ = 0x08;
//BYTE SleepTimer_WAIT_RELOAD = 0x00;

char sleap[ ] = "Sleep Mode";
char active[ ] = "Danger!!!";
char clean[ ] = "                ";

int ControllerMode = 0;
int gCount = 0;

void welcomeScreen(void);//Declaration of the function that prints Welcome String on Hyperterminal

void getup(void)
{
	ControllerMode = 1;
	UnloadConfig_mainConfig();
	
	LoadConfig_signalConfig();	
	Blink_Start();		
}

void signal(void)
{
	gCount++;
	if (gCount == 3) 
	{
		Blink_Stop();
		UnloadConfig_signalConfig();
		
		LoadConfig_mainConfig();
	Danger_Start();

		gCount = 0;
	}
}

void gotosleep(void)
{
	Counter_Stop();
	UnloadConfig_dengerConfig();
	
	LoadConfig_mainConfig();
	Danger_Start();
}

void blink(void)
{
	Danger_Stop();	
	ControllerMode = 0;	
	//M8C_Sleep;
}

void main(void)
{	
	char *strPtr; 
	int index;
	LCD_Start();                              // Initialize LCD hardware
		
	Danger_EnableInt();
	Counter_EnableInt();
	Blink_EnableInt();
	
	UART_EnableInt();
	UART_CmdReset(); 
    //Enable RX interrupts
	UART_IntCntl(UART_ENABLE_RX_INT);       
	//set parity as zero and start the UART 
 	UART_Start(UART_PARITY_NONE);            
 	//Clear the screen in Hyper terminal window
 	UART_PutChar(12); 
	
	welcomeScreen();
	
#ifdef USE_GPIO_INT
	M8C_EnableIntMask (INT_MSK0, INT_MSK0_GPIO);
#endif

#ifdef USE_SLEEP_INT	
	SleepTimer_Start();
    SleepTimer_SetInterval(SleepTimer_512_HZ);   // Set interrupt to a 64 Hz rate
    SleepTimer_EnableInt();
#endif

	M8C_EnableGInt;
	
	if (gpioFlag)                           /* If flag has been set by the ISR */
        {
            for(index = 0; index < 10000; index++)/* Debounce the GPIO */
		
            SleepPrep();                        /* Configure PSOC for sleep */
		
            M8C_Sleep;                          /* Sleep the PSoC */
		    asm("nop");                         /* A nop is used for pre-fetch code */
	
            M8C_ClearIntFlag(INT_CLR0, INT_MSK0_GPIO);  /* Clear the GPIO interrupts */ 
	
            M8C_EnableGInt;                     /* Enable global interrupts again */
		
            WakeUpRestore();                    /* Reconfigure the PSoC to active conditions */
		
            gpioFlag = 0;                       /* Clear sleep trigger flag. */
        }
	
	while(1) {				
		if (ControllerMode == 1){
			LCD_Position(0,0);              
			LCD_PrString(active);
			LCD_Position(1,0);
			LCD_PrString(clean);
		}	
		else {
			LCD_Position(0,0);
			LCD_PrString(clean);
			LCD_Position(1,0);              
			LCD_PrString(sleap);
		}
		
	//#ifndef USE_GPIO_INT
       // NoGpioSleep();                          /* Put the PSoC to sleep */
    //#endif
		
		if (UART_bCmdCheck()) {                  // Wait for command Terminator
                UART_CPutString("\n\rFound command to get up\r\nCommand =>");
	//Reset command buffer and flags
            UART_CmdReset();

	// Print Welcome String
            welcomeScreen();
        }	    
    } 		
}
void welcomeScreen(void)
{
    UART_CPutString("\n\rWelcome to PSoC UART test program. V1.0");    
    UART_CPutString("\n\rPress <ENTER> or enter any symbol and press <ENTER> to get system up");
    UART_CPutString("\n\r");
}