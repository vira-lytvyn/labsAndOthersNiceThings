/* Defined Interrupt Sources */
#define USE_GPIO_INT                /* Use GPIO interrupt to wake PSoC */
//#define USE_SLEEP_INT             /* Use sleep timer interrupt to wake PSoC */

#define CT_SC_BLOCKS                /* Disable CT and SC blocks in sleep */

#define ACB_CT_SC_ENABLE 0x03

/* Function Prototypes */
void SleepPrep(void);               /* Configures the PSoC for sleep */
void WakeUpRestore(void);           /* Restores the pre-sleep configuration */
void NoGpioSleep(void);             /* Forces the PSoC to sleep if no GPIO ISR is defined */