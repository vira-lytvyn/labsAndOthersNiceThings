#include "global.h"

#pragma interrupt_handler GPIO_ISR              /* Ensures reti from GPIO_ISR */
void GPIO_ISR(void)
{
	gpioFlag = 1; 		/* Set flag indicating gpio interrupt */
}