#include "global.h"

int gpioFlag = 0; 

void SleepPrep(void)
{
    M8C_DisableGInt;    /* Disable interrupts before M8C_Sleep */
	
#ifdef ANALOG_REF  
    /* Turn off analog ref */
    ARF_CR &= ~ARF_CR_REFPWR;     
#endif

#ifdef ANALOG_OUTPUT_BUFFERS	
    /* Turn off analog buffers */
    ABF_CR0 &= ~(ABF_CR0_ABUF1EN | ABF_CR0_ABUF2EN | ABF_CR0_ABUF0EN | ABF_CR0_ABUF3EN);    
#endif
	
#ifdef CT_SC_BLOCKS 	
    /* Disable CT Blocks, the registers are ACBmnCR2, where m stands for row and n stands for column */
    ACB00CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 0 */
    ACB01CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 1 */
    ACB02CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 2 */
    ACB03CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 3 */
    
    /* Disable typeC SC block, the registers are ASCmnCR3, where m stands for row and n stands for column */
    ASC10CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 1 and column 0 */
    ASC12CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 1 and column 2 */
    ASC21CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 2 and column 1 */
    ASC23CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 2 and column 3 */
    
    /* Disable typeD SC block, the registers are ASDmnCR3, where m stands for row and n stands for column */
    ASD11CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 1 and column 1 */
    ASD13CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 1 and column 3 */
    ASD20CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 2 and column 0 */
    ASD22CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 2 and column 2 */
#endif

#ifdef DRIVE_MODES
    /* Original state: DM = 001 = Strong */
    PRT2DM0 &= ~PORT_2_0;   /* DM = 000 = Pull-down */
    PRT2DM1 |= PORT_2_0;    /* DM = 010 = Hi-Z */
    PRT2DM2 |= PORT_2_0;    /* MM = 110 = Hi-Z Analog */
#endif
	
#ifdef USE_SLEEP_INT
    M8C_ClearWDTAndSleep; /* Reset the sleep timer count (will also affect RTC) */
#endif
}

void WakeUpRestore(void)
{	
#ifdef ANALOG_OUTPUT_BUFFERS	
    ABF_CR0 |= ABF_CR0_ABUF1EN | ABF_CR0_ABUF2EN | ABF_CR0_ABUF0EN | ABF_CR0_ABUF3EN;    /* Turn on analog buffers */
#endif

#ifdef ANALOG_REF
    ARF_CR |= ARF_CR_SCPWR;     /* Turn on analog blocks */
#endif

#ifdef CT_SC_BLOCKS 	
    ACB00CR2 |= ACB_CT_SC_ENABLE; /* Turn on the CT Block of row 0 and column 0 */
    ACB01CR2 |= ACB_CT_SC_ENABLE; /* Turn on the CT Block of row 0 and column 1 */    
#endif

#ifdef DRIVE_MODES    
    PRT2DM2 &= ~PORT_2_0;       /* DM = 010 = Hi-Z */
    PRT2DM1 &= ~PORT_2_0;       /* DM = 000 = Pull-Down */
    PRT2DM0 |= PORT_2_0;        /* DM = 001 = Strong */	
#endif
	M8C_EnableGInt;             /* Enable Global Interrupts */
}

void NoGpioSleep(void)
{
    WORD index1, index2;
    SleepPrep();                                
    M8C_DisableGInt;                            
    M8C_Sleep;                 
    asm("nop");                                 
    M8C_EnableGInt;                             
    WakeUpRestore();                            
    for(index1 = 0; index1 < 14; index1++)      
    {
        for(index2 = 0; index2 < 30000; index2++);
    }
    M8C_ClearWDTAndSleep;                       
}
