/*****************************************************************************
* File Name: main.c  
* 
* Version: 2.0
*
* Project Description:
* This project demonstrates how to put the PSoC to sleep and wake it again
* using the Sleep Timer and GPIO interrupts. It also demonstrates the use of
* different registers to disable portions of the PSoC that may continue to 
* draw power during sleep. Monitoring the power consumption of the PSoC during
* normal operation and sleep mode shows the difference in current.
*
* User Modules:
* LED v1.4
*   Pin: Port P2[0]
*   Drive: Active HIGH
* SleepTimer v1.0
*   Interval: 1 Hz 
*   TickCounterSize: 4 Byte 
* AMPINV v4.3
*   Gain: -1.000 
*   Input: AGND 
*   AnalogBus: AnalogOutBus_0 (routed to P0[3])
* PGA v3.2
*   Gain: 1.000 
*   Input: AnalogColumn_InputSelect_1 (routed to P0[4])
*   Reference: AGND 
*   AnalogBus: Disable
*
* Owner:
*  GULA
*
* Related Document:
*  AN47310
*
* Hardware Dependency:
* CY3210-MiniEval1 Hardware Notes:
* Remove R5 and PO1 from the board for proper current measurement.
* Install CY8C27443-24PVXI into socket U1.
* Set JP1 for 28-Pin operation.
*
* Code Tested With:
*  1. PSoC Designer5.2 Build 2551
*  2. ImageCraft Compiler Standard V7.05
*  3. Device Tested: CY8C27443
*
******************************************************************************
* Copyright (2012), Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is 
* protected by and subject to worldwide patent protection (United States and 
* foreign), United States copyright laws and international treaty provisions. 
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable 
* license to copy, use, modify, create derivative works of, and compile the 
* Cypress Source Code and derivative works for the sole purpose of creating 
* custom software in support of licensee product to be used only in conjunction 
* with a Cypress integrated circuit as specified in the applicable agreement. 
* Any reproduction, modification, translation, compilation, or representation of 
* this software except as specified above is prohibited without the express 
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH 
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the 
* materials described herein. Cypress does not assume any liability arising out 
* of the application or use of any product or circuit described herein. Cypress 
* does not authorize its products for use as critical components in life-support 
* systems where a malfunction or failure may reasonably be expected to result in 
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of 
* such use and in doing so indemnifies Cypress against all charges. Use may be 
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/

#include "global.h"

/*****************************************************************************
* Function Name: main()
******************************************************************************
* Summary:
* This function is the main loop for the example project. It sets 
* the analog system to full power, unmasks any defined interrupt sources, 
* starts the sleep timer (if defined), and turns on the LED. It then enters an
* infinite loop to either wait for a GPIO interrupt (if defined) or call sleep
* every time through while loop.
*
* Parameters:
*  void
*
* Return:
*  void 
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
void main(void)
{	
    int index;
    
    ARF_CR |= ARF_CR_SCPWR;                     /* Set analog to full power for maximum current */
	
	AMPINV_Start(AMPINV_HIGHPOWER);             /* Start inverting amplifier */
	
	PGA_Start(PGA_HIGHPOWER);                   /* Start PGA at high power */

#ifdef USE_GPIO_INT
	M8C_EnableIntMask(INT_MSK0, INT_MSK0_GPIO); /* Unmask GPIO interrupt */
#endif

    /* Use Sleep Timer User Module if you want to use the Sleep timer to wake up the device from sleep mode */
#ifdef USE_SLEEP_INT
	SleepTimer_Start();                         /* Turn on the Sleep Timer */
	
    /* The Sleep Time Interval can be set to 1 Hz, 8 Hz, 64 Hz or 512 Hz */
	SleepTimer_SetInterval(SleepTimer_1_HZ);    /* Set interrupt to 1 Hz Rate. */
	
	SleepTimer_EnableInt();                     /* Enable Sleep Timer interrupts. */
#endif
	
	M8C_EnableGInt;                             /* Enable Global Interrupts */
	
	LED_Switch(PORT_2_0);                       /* Turn on LED (drive P2[0] HIGH) */
	
    while(1)
    {		
        if (gpioFlag)                           /* If flag has been set by the ISR */
        {
            for(index = 0; index < 10000; index++)/* Debounce the GPIO */
		
            SleepPrep();                        /* Configure PSOC for sleep */
		
            M8C_Sleep;                          /* Sleep the PSoC */
		    asm("nop");                         /* A nop is used for pre-fetch code */
	
            M8C_ClearIntFlag(INT_CLR0, INT_MSK0_GPIO);  /* Clear the GPIO interrupts */ 
	
            M8C_EnableGInt;                     /* Enable global interrupts again */
		
            WakeUpRestore();                    /* Reconfigure the PSoC to active conditions */
		
            gpioFlag = 0;                       /* Clear sleep trigger flag. */
        }
	
    #ifndef USE_GPIO_INT
        NoGpioSleep();                          /* Put the PSoC to sleep */
    #endif
	}
}