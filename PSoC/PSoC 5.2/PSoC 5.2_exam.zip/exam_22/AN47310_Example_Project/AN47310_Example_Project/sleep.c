/*****************************************************************************
* File Name: sleep.c  
* 
* Version: 2.0
*
* Description:
* This file contains the APIs that are used to configure the PSoC for Sleep mode
* and wake up the PSoC from sleep mode.
*
* Owner:
*  GULA
*
* Related Document:
*  AN47310
*
* Hardware Dependency:
* CY3210-MiniEval1 Hardware Notes:
* Remove R5 and PO1 from the board for proper current measurement.
* Install CY8C27443-24PVXI into socket U1.
* Set JP1 for 28-Pin operation.
*
* Code Tested With:
*  1. PSoC Designer5.2 Build 2551
*  2. ImageCraft Compiler Standard V7.05
*  3. Device Tested: CY8C27443
*
******************************************************************************
* Copyright (2012), Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is 
* protected by and subject to worldwide patent protection (United States and 
* foreign), United States copyright laws and international treaty provisions. 
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable 
* license to copy, use, modify, create derivative works of, and compile the 
* Cypress Source Code and derivative works for the sole purpose of creating 
* custom software in support of licensee product to be used only in conjunction 
* with a Cypress integrated circuit as specified in the applicable agreement. 
* Any reproduction, modification, translation, compilation, or representation of 
* this software except as specified above is prohibited without the express 
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH 
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED 
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the 
* materials described herein. Cypress does not assume any liability arising out 
* of the application or use of any product or circuit described herein. Cypress 
* does not authorize its products for use as critical components in life-support 
* systems where a malfunction or failure may reasonably be expected to result in 
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of 
* such use and in doing so indemnifies Cypress against all charges. Use may be 
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/

#include "global.h"

int gpioFlag = 0; 

/*****************************************************************************
* Function Name: SleepPrep()
******************************************************************************
* Summary:
* This function configures the PSoC for sleep according to the Sleep Mode
* configuration Modifiers defined in sleep.h.
*
* Parameters:
*  void
*
* Return:
*  void 
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
void SleepPrep(void)
{
    M8C_DisableGInt;    /* Disable interrupts before M8C_Sleep */
	
#ifdef ANALOG_REF  
    /* Turn off analog ref */
    ARF_CR &= ~ARF_CR_REFPWR;     
#endif

#ifdef ANALOG_OUTPUT_BUFFERS	
    /* Turn off analog buffers */
    ABF_CR0 &= ~(ABF_CR0_ABUF1EN | ABF_CR0_ABUF2EN | ABF_CR0_ABUF0EN | ABF_CR0_ABUF3EN);    
#endif
	
#ifdef CT_SC_BLOCKS 	
    /* Disable CT Blocks, the registers are ACBmnCR2, where m stands for row and n stands for column */
    ACB00CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 0 */
    ACB01CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 1 */
    ACB02CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 2 */
    ACB03CR2 &= ~ACB_CT_SC_ENABLE; /* Disable CT Block of row 0 and column 3 */
    
    /* Disable typeC SC block, the registers are ASCmnCR3, where m stands for row and n stands for column */
    ASC10CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 1 and column 0 */
    ASC12CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 1 and column 2 */
    ASC21CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 2 and column 1 */
    ASC23CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeC SC block of row 2 and column 3 */
    
    /* Disable typeD SC block, the registers are ASDmnCR3, where m stands for row and n stands for column */
    ASD11CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 1 and column 1 */
    ASD13CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 1 and column 3 */
    ASD20CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 2 and column 0 */
    ASD22CR3 &= ~ACB_CT_SC_ENABLE; /* Disable typeD SC block of row 2 and column 2 */
#endif

#ifdef DRIVE_MODES
    /* Original state: DM = 001 = Strong */
    PRT2DM0 &= ~PORT_2_0;   /* DM = 000 = Pull-down */
    PRT2DM1 |= PORT_2_0;    /* DM = 010 = Hi-Z */
    PRT2DM2 |= PORT_2_0;    /* MM = 110 = Hi-Z Analog */
#endif
	
#ifdef USE_SLEEP_INT
    M8C_ClearWDTAndSleep; /* Reset the sleep timer count (will also affect RTC) */
#endif
}


/*****************************************************************************
* Function Name: WakeUpRestore()
******************************************************************************
* Summary:
* This function restores the PSoC to normal operation after sleep 
* according to the Sleep Mode Configuration Modifiers defined in sleep.h.
*
* Parameters:
*  void
*
* Return:
*  void 
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
void WakeUpRestore(void)
{	
#ifdef ANALOG_OUTPUT_BUFFERS	
    ABF_CR0 |= ABF_CR0_ABUF1EN | ABF_CR0_ABUF2EN | ABF_CR0_ABUF0EN | ABF_CR0_ABUF3EN;    /* Turn on analog buffers */
#endif

#ifdef ANALOG_REF
    ARF_CR |= ARF_CR_SCPWR;     /* Turn on analog blocks */
#endif

#ifdef CT_SC_BLOCKS 	
    /* Based on which CT, typeC SC or typeD SC block are used, the user can enable and disable them in the Sleep
    Mode, Turn on the CT Blocks, the registers are ACBmnCR2, where m stands for row and n stands for column */
    
    /* In this example one 2 of these blocks are ennabled hence the rest of the lines are commented. Based on
    your design un-comment the blocks which are enabled */
    ACB00CR2 |= ACB_CT_SC_ENABLE; /* Turn on the CT Block of row 0 and column 0 */
    ACB01CR2 |= ACB_CT_SC_ENABLE; /* Turn on the CT Block of row 0 and column 1 */
    //ACB02CR2 |= ACB_CT_SC_ENABLE; /* Turn on the CT Block of row 0 and column 2 */
    //ACB03CR2 |= ACB_CT_SC_ENABLE; /* Turn on the CT Block of row 0 and column 3 */
    
    /* Turn on the typeC SC block, the registers are ASCmnCR3, where m stands for row and n stands for column */
    //ASC10CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeC SC block of row 1 and column 0 */
    //ASC12CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeC SC block of row 1 and column 2 */
    //ASC21CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeC SC block of row 2 and column 1 */
    //ASC23CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeC SC block of row 2 and column 3 */
    
    /* Turn on the typeD SC block, the registers are ASDmnCR3, where m stands for row and n stands for column */
    //ASD11CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeD SC block of row 1 and column 1 */
    //ASD13CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeD SC block of row 1 and column 3 */
    //ASD20CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeD SC block of row 2 and column 0 */
    //ASD22CR3 |= ACB_CT_SC_ENABLE; /* Turn on the typeD SC block of row 2 and column 2 */
#endif

#ifdef DRIVE_MODES    
    PRT2DM2 &= ~PORT_2_0;       /* DM = 010 = Hi-Z */
    PRT2DM1 &= ~PORT_2_0;       /* DM = 000 = Pull-Down */
    PRT2DM0 |= PORT_2_0;        /* DM = 001 = Strong */	
#endif

	M8C_EnableGInt;             /* Enable Global Interrupts */
}

/*****************************************************************************
* Function Name: NoGpioSleep()
******************************************************************************
* Summary:
* This function is used in place of the ISR for the GPIO interrupt
* if it is not defined as an interrupt source. It prepares the PSoC for sleep 
* and sets the SLEEP bit. When a wakeup occurs, it delays for a short time to
* simulate active mode activities before resetting the Sleep Timer count.
*
* Parameters:
*  void
*
* Return:
*  void 
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
void NoGpioSleep(void)
{
    WORD index1, index2;
	
    /* Configure PSoC 1 for sleep */
    SleepPrep();                                
	
    /* Disable interrupts during sleep */
    M8C_DisableGInt;                            
	
    /* Enable Sleep in PSoC 1 */
    M8C_Sleep;                 
    
    /* A nop is used for pre-fetch code */
    asm("nop");                                 

    /* Enable global interrupts again */
    M8C_EnableGInt;                             
	
    /* Reconfigure the PSoC to active conditions */
    WakeUpRestore();                            

    /* Active mode delay to allow for power measuring */
    for(index1 = 0; index1 < 14; index1++)      
    {
        for(index2 = 0; index2 < 30000; index2++);
    }
	
    /* Reset the sleep timer count (will also affect RTC) */
    M8C_ClearWDTAndSleep;                       
}
