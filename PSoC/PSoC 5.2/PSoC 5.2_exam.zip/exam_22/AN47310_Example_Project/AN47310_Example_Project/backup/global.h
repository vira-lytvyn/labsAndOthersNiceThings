#include <m8c.h>        			/* Device-specific constants and macros */
#include "PSoCAPI.h"    			/* PSoC API definitions for all User Modules */
#include "sleep.h"

#define PORT_2_0    0x01

extern int gpioFlag;                /* Flag set by GPIO ISR */

/* Function Prototypes */
void GPIO_ISR(void);                /* ISR for the GPIO interrupt */