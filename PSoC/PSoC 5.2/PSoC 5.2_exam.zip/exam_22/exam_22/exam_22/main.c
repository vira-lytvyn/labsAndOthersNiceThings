//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "PSoCGPIOINT.h"

//BYTE SleepTimer_64_HZ = 0x08;
//BYTE SleepTimer_WAIT_RELOAD = 0x00;

char sleap[ ] = "Sleep Mode";
char active[ ] = "Danger!!!";

void getup(void)
{
//	SleepTimer_Stop();
	Danger_Start();//
	LCD_Position(0,0);              
	LCD_PrString(active);
}

void blink(void)
{
	Danger_Stop();	
	LCD_Position(1,0);              
	LCD_PrString(sleap);
}

void main(void)
{
	M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts
	// Insert your main routine code here.
	
	LCD_Start();                      
	LCD_Position(0,0);              
	LCD_PrString(sleap);
	
	Danger_EnableInt();
	M8C_EnableIntMask (INT_MSK0, INT_MSK0_GPIO);
	
	SleepTimer_Start();
	
	SleepTimer_SetInterval(SleepTimer_64_HZ);   // Set interrupt to a 64 Hz rate

    SleepTimer_EnableInt();
	
	while (1){
		SleepTimer_SyncWait(1/64, SleepTimer_WAIT_RELOAD);
	}
}
