//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include "global.h"

//BYTE SleepTimer_64_HZ = 0x08;
//BYTE SleepTimer_WAIT_RELOAD = 0x00;
char *strPtr;

char sleap[ ] = "Sleep Mode";
char active[ ] = "Danger!!!";
char clean[ ] = "                ";

int ControllerMode = 0;
//int gCount = 0;
int gBlink = 0;
int gLight = 0;

void welcomeScreen(void);//Declaration of the function that prints Welcome String on Hyperterminal

void getup(void)
{            
    UART_CPutString("\n\rFound command to get up\r\n");
	UART_CPutString("\n\rDanger! Danger! Danger!\r\n");
	Danger1_Start();
	ControllerMode = 1;	
}

void blink(void)
{
		Danger1_Stop();	
		Danger2_Start();
}

void blink2(void)
{
		Danger2_Stop();
		gBlink++;
		if (gBlink == 10){			
				ControllerMode = 0;	
				UART_CPutString("\n\rSystem go to Sleep mode");
				UART_CmdReset();
				welcomeScreen();
				gBlink = 0;
		}
		else{
			Danger1_Start();
		}				
}

void main(void)
{		 
	int index;
	LCD_Start();      
		
	Danger1_EnableInt();
	Danger2_EnableInt();
	
	UART_EnableInt();
	UART_CmdReset(); 
    //Enable RX interrupts
	UART_IntCntl(UART_ENABLE_RX_INT);       
	//set parity as zero and start the UART 
 	UART_Start(UART_PARITY_NONE);            
 	//Clear the screen in Hyper terminal window
 	UART_PutChar(12); 
	
	welcomeScreen();
	
#ifdef USE_GPIO_INT
	M8C_EnableIntMask (INT_MSK0, INT_MSK0_GPIO);
#endif

#ifdef USE_SLEEP_INT	
	SleepTimer_Start();
    SleepTimer_SetInterval(SleepTimer_512_HZ);   // Set interrupt to a 64 Hz rate
    SleepTimer_EnableInt();
#endif

	M8C_EnableGInt;
	
	if (gpioFlag)                           /* If flag has been set by the ISR */
        {
            for(index = 0; index < 10000; index++)/* Debounce the GPIO */
		
            SleepPrep();                        /* Configure PSOC for sleep */
		
            M8C_Sleep;                          /* Sleep the PSoC */
		    asm("nop");                         /* A nop is used for pre-fetch code */
	
            M8C_ClearIntFlag(INT_CLR0, INT_MSK0_GPIO);  /* Clear the GPIO interrupts */ 
	
            M8C_EnableGInt;                     /* Enable global interrupts again */
		
            WakeUpRestore();                    /* Reconfigure the PSoC to active conditions */
		
            gpioFlag = 0;                       /* Clear sleep trigger flag. */
        }
	
	while(1) {				
		if (ControllerMode == 1){
			LCD_Position(0,0);              
			LCD_PrString(active);
			LCD_Position(1,0);
			LCD_PrString(clean);
		}	
		else {
			LCD_Position(0,0);
			LCD_PrString(clean);
			LCD_Position(1,0);              
			LCD_PrString(sleap);
		}
    } 		
}
void welcomeScreen(void)
{
    UART_CPutString("\n\rWelcome to PSoC UART test program. V1.0");    
    UART_CPutString("\n\rPlease, press <ENTER> or enter any symbol to get system up");
    UART_CPutString("\n\r");
}