//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules


void main(void)
{
	// M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts
	
	char str[ ] = "Laborat 2 Vira";   
	LCD_1_Start();                      
	LCD_1_Position(0,3);              
	LCD_1_PrCString("23.09.2012");      
	LCD_1_Position(1,0);              
	LCD_1_PrString(str);
	
	PRT1DR = 0x20 ; //Turns the LED On.
    while ( 1 )
 	{
		
		if (PRT0DR & 0x01 ) //Checks the state of the button. If the button is pressed then it will execute.
 			{
				PRT1DR = 0x00 ; //Turns the LED Of.
 			}
		else
		{
			PRT1DR = 0x20 ;
		}
 	}
	
// Insert your main routine code here.
}
