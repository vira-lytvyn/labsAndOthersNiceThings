/*****************************************************************************
* File Name: thermistor.c
*
* Version: 2.0
*
* Description:
* This file contains the the function required in the to measure the resistance
* , calculate the temperature and display the results.
*
* Note:
* 
* Owner:
* Aditya Yadav (adiy@cypress.com)
*
* Related Document:
* AN2017.pdf
* AN2017_S_H_Constant_Calc.xls
*
* Hardware Dependency:
* The circuit should be connected as shown in the AN2017 for the code to work as expected.
*
* Code Tested With:
* 1. PSoC Designer5.2 SP1
* 2. ImageCraft C Compiler
*
******************************************************************************
* Copyright (2011), Cypress Semiconductor Corporation.
******************************************************************************
* This software is owned by Cypress Semiconductor Corporation (Cypress) and is
* protected by and subject to worldwide patent protection (United States and
* foreign), United States copyright laws and international treaty provisions.
* Cypress hereby grants to licensee a personal, non-exclusive, non-transferable
* license to copy, use, modify, create derivative works of, and compile the
* Cypress Source Code and derivative works for the sole purpose of creating
* custom software in support of licensee product to be used only in conjunction
* with a Cypress integrated circuit as specified in the applicable agreement.
* Any reproduction, modification, translation, compilation, or representation of
* this software except as specified above is prohibited without the express
* written permission of Cypress.
*
* Disclaimer: CYPRESS MAKES NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, WITH
* REGARD TO THIS MATERIAL, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
* WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
* Cypress reserves the right to make changes without further notice to the
* materials described herein. Cypress does not assume any liability arising out
* of the application or use of any product or circuit described herein. Cypress
* does not authorize its products for use as critical components in life-support
* systems where a malfunction or failure may reasonably be expected to result in
* significant injury to the user. The inclusion of Cypress' product in a life-
* support systems application implies that the manufacturer assumes all risk of
* such use and in doing so indemnifies Cypress against all charges. Use may be
* limited by and subject to the applicable Cypress software license agreement.
*****************************************************************************/
#include "thermistor.h"

/* SteinHart-Hart Constants */
const float rA = 0.000891358; 
const float rB = 0.000250618;
const float rC = 0.000000197;

/* Kelvin Temperature */
const float tK = 273.15;

#ifdef FLOAT_MATH
float rR=0;		/* resistance calculated by float math */
float rT=0; 	/* temperature calculated with real math */
#endif

#ifdef LONG_MATH
long  lR=0;		/* resistance calculated by long math */
int iT=0; 		/* temperature calculated with a look up table */
/* Tempuature look up table */
const long lTempTable[] = 
{27219	,
26079	,
24993	,
23958	,
22971	,
22030	,
21133	,
20277	,
19459	,
18680	,
17935	,
17224	,
16545	,
15896	,
15276	,
14683	,
14117	,
13575	,
13056	,
12560	,
12086	,
11632	,
11197	,
10781	,
10382	,
10000	,
9634	,
9283	,
8947	,
8625	,
8316	,
8019	,
7735	,
7462	,
7200	,
6948	,
6707	,
6475	,
6252	,
6038	,
5833	,
5635	,
5445	,
5263	,
5087	,
4918	,
4756	,
4600	,
4449	,
4305	,
4165	,
4031	,
3902	,
3778	,
3658	,
3542	,
3431	,
3324	,
3220	,
3121	,
3024	,
2932	,
2842	,
2756	,
2673	,
2592	,
2515	,
2440	,
2368	,
2298	,
2231	,
2165	,
2102	,
2042	,
1983	,
1926	,
1871	,
1818	,
1767	,
1717	,
1669	
};
#endif

/*****************************************************************************
* Function Name: Thermistor_Start()
******************************************************************************
* Summary:
* This function starts the User Modules required to measure the resistance of 
* the thermistor. It also connects the test mux of the two PGA's to the 
* respective analog bus.
*
* Parameters:
* None
* Return:
* None
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
void Thermistor_Start (void)
{
	RefLow_Start(RefLow_HIGHPOWER);
	Buffer_Start(Buffer_HIGHPOWER);
	ADCINCVR_1_Start(ADCINCVR_1_HIGHPOWER); 
	LCD_Start();
	
	ACC00CR2 |= (TMUXEN | REFHI);  /* set testmux to ref+ */
	ACC01CR2 |= (TMUXEN | REFLO);  /* set testmux to ref- */
}

/*****************************************************************************
* Function Name: Measure_Resistance()
******************************************************************************
* Summary:
* This function measures the voltage at the three pins and calculates the 
* resistance with the selected method. The calculated value is stored for 
* further processing.
*
* Parameters:
* None
* Return:
* None
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
void Measure_Resistance (void)
{
	int iV0=0;
	int iV1=0;
	int iV2=0;
	
	iV0 = Measure_Voltage (AMUX4_PORT0_3);		/* Reading V0 (Vref+) */
	iV1 = Measure_Voltage (AMUX4_PORT0_1);		/* Reading V1 (Signal)*/
	iV2 = Measure_Voltage (AMUX4_PORT0_5);		/* Reading V2 (Vref-) */

	#ifdef FLOAT_MATH
	/* Resistance calculated with floating point math */
	rR  = (((float)(iV0-iV1))/((float)(iV1-iV2)));
	rR *= (float)RREF;
	#endif
	
	#ifdef LONG_MATH
	/* Resistance calculated in long integer math */
	lR = ((long)RREF) *((long)(iV0-iV1));
	lR += ((long)(iV1-iV2))/((long)2);
	lR = ((long)lR / ( (long)(iV1-iV2)));	
	#endif
}

/*****************************************************************************
* Function Name: Measure_Voltage()
******************************************************************************
* Summary:
* This function measures the voltage at the requested pin and returns the 
* value.
*
* Parameters:
* bChannel: Pin at which voltage is to be measured
* Return:
* Measured Voltage at the resuested pin.
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
int Measure_Voltage (BYTE bChannel)
{
	int iV=0;
	
	AMUX4_InputSelect(bChannel);      
	ADCINCVR_1_ClearFlag();
	ADCINCVR_1_GetSamples(1);      
	while(!ADCINCVR_1_fIsData());
	iV = ADCINCVR_1_iGetData();
	
	return iV;
}

/*****************************************************************************
* Function Name: Calculate_Temperature()
******************************************************************************
* Summary:
* This function calculates the temperature using the Steinhart-Hart Equation
* or the generated Look-Up-Table.
*
* Parameters:
* None
* Return:
* None
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/
void Calculate_Temperature(void)
{
	#ifdef FLOAT_MATH
	float rLogR=0 ;
	/* Temperature calculated with equation */
	rLogR = log(rR);
	rT =(1/(rA+(rB*rLogR)+(rC*pow(rLogR,3.0)))) - tK; /* Steinhart-Hart Equation */
	#endif
	
	#ifdef LONG_MATH
	/* Temperature calculated with LUT */
	for(iT = 0;lTempTable[iT] >= lR; iT++);
	#endif	
}

/*****************************************************************************
* Function Name: Display_Results()
******************************************************************************
* Summary:
* This function displays the measured resistance and the calculated temperature.
*
* Parameters:
* None
* Return:
* None
*
* Theory:
*
* Side Effects:
*
* Note:
*
*****************************************************************************/

void Display_Results(void)
{
	int Status=0;
	char lBuff[10];
	char *fBuff;
	/* Clear LCD */
	LCD_Position(0,0);
	LCD_PrCString("              ");
	LCD_Position(1,0);
	LCD_PrCString("              ");

	#ifdef FLOAT_MATH
	/* Calc Resistance */
	LCD_Position(0,0);
	LCD_PrCString("R=");
	fBuff = ftoa(rR, &Status);
	LCD_PrString(fBuff);
	
	/* Calc TEMP */
	LCD_Position(1,0);
	LCD_PrCString("T=");
	fBuff = ftoa(rT, &Status);
	LCD_PrString(fBuff);
	#endif
	
	#ifdef LONG_MATH
	/* LUT Resistance */
	LCD_Position(0,0);
	LCD_PrCString("R=");
	LCD_PrString(ltoa(lBuff,lR,10));	
	
	/* LUT TEMP */
	LCD_Position(1,0);
	LCD_PrCString("T=");
	LCD_PrString(itoa(lBuff,iT,10));
	#endif
}