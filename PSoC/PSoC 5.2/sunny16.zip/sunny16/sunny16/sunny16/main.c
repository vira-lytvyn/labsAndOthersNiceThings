//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include <stdlib.h>
#include <stdio.h>

int gCheck = 0;
int iResult;
int gIndex = 0;
float fResult;
char *gStrResult;
int gValues[20] = {127, 166, 201, 229, 247, 253, 247, 229, 201, 166, 
					127, 87, 52, 24, 6, 0, 6, 24, 52, 87};
					

void countInt(void) {
	Counter16_Start();
	gIndex++;
	gCheck = 1;
	if (gIndex > 19) {
		Counter16_Stop();
	}
}

void main(void)
{
    int temp = 0;
		int i = 0;
	LCD_Start();
	LCD_Position(0, 0);
	LCD_PrCString("Laboratorna 16");
	
	M8C_EnableGInt;
	
	UART_Start(UART_PARITY_NONE);
	UART_CPutString("DAC8");
	UART_PutCRLF();
	
	for (i = 0; i < 20; i++)
	{
		float U = gValues[i] * 5.0 / 255;
		gStrResult = ftoa(U, 0);
		UART_PutString(gStrResult);
		UART_PutCRLF();
	}
		
	Counter16_EnableInt();
	Counter16_Start();
	
	PGA_Start(PGA_HIGHPOWER);
	DAC8_Start(DAC8_HIGHPOWER);
	DAC8_WriteBlind(0);
	ADCINC12_Start(ADCINC12_HIGHPOWER);
	ADCINC12_GetSamples(0);
	
	
	UART_CPutString("ADC");
	UART_PutCRLF();
	while (1) {
	if (gIndex <= 19) {
		DAC8_WriteBlind(gValues[gIndex]);
		if (ADCINC12_fIsDataAvailable() != 0 && gCheck == 1) {
		gCheck = 0;
			iResult = ADCINC12_iGetData();
			ADCINC12_ClearFlag();
			
			fResult = 0.00122 * (float)iResult;
			gStrResult = ftoa(fResult, 0);
			
			LCD_Position(1, 0);
			LCD_PrString(gStrResult);
			
			UART_PutString(gStrResult);
			UART_PutCRLF();
		}
	}
	}
}
