//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "stdlib.h"
#include <math.h>

int iData;			// Variable that stores the ADC result
float fVolts;		// Variable that stores the converted 					voltage value
float fScaleFactor;	// Variable that stores the 						volts/count scale factor
char *pResult;		// Pointer used to store the result 					returned by ftoa function
int iStatus;		// Status variable for the ftoa 						function


void main(void)
{
	// M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts
	// Insert your main routine code here.
	PGA_1_Start(PGA_1_HIGHPOWER); // Start PGA with Highpower
 	LCD_1_Start();			 // Start LCD
 	LCD_1_Position(0,0);		// Set LCD position to row 0 						column 0
 	LCD_1_PrCString("MEASURED VOLTAGE");	// Print string 				"MEASURED VOLTAGE" on LCD
	
	M8C_EnableGInt; 		// Enable Global Interrupts
 	
	ADCINCVR_1_Start(ADCINCVR_1_HIGHPOWER); // Start ADC by powering SC 						block at High Power
	ADCINCVR_1_GetSamples(0); 		// Have ADC run continuously
	fScaleFactor = (float)5/(float)4096;// Calculate Scale Factor.
	
	for(;;)		// Infinite loop
  	{ 
		while(ADCINCVR_1_fIsDataAvailable() == 0);         // Loop until value 	ready
		iData=ADCINCVR_1_iGetData();	// Read ADC result
		ADCINCVR_1_ClearFlag(); 		// Clear ADC flag
		fVolts = fScaleFactor*(float)iData;	// Calculate 			voltage using ADC result and scale factor
		fVolts = floor(fVolts);
		pResult = ftoa(fVolts,&iStatus );	// Convernt 			Float value of voltage into ASCII string
		LCD_1_Position(1,0);		// Set LCD position to 							row 1 column 0
		LCD_1_PrString(pResult);	// Print voltage value on 	LCD
		LCD_1_PrCString(" V");	// Print string " V" on 						LCD after voltage value
  	}
}
