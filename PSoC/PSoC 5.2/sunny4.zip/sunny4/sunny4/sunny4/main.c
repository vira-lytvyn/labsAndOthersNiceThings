//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules

void vr1(void)
{
	Counter16_2_Start();
	Counter16_1_Stop();
}

void vr2(void)
{
	Counter16_1_Start();
	Counter16_2_Stop();
}

void main(void)
{
	// M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts
	// Insert your main routine code here.
	char str[ ] = "Laboratorna4Vira";   
	LCD_1_Start();                      
	LCD_1_Position(0,3);              
	LCD_1_PrCString("06.10.2012");      
	LCD_1_Position(1,0);              
	LCD_1_PrString(str);
	
	Counter16_1_EnableInt();
	Counter16_2_EnableInt();
	M8C_EnableGInt;
	
	
	while (1)
	{
		if (PRT0DR & 0x01 ) //Checks the state of the button. If the button is pressed then it will execute.
		{
			Counter16_1_Start();
			Counter16_2_Stop();
		}
	}

}
