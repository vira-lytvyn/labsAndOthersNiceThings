//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include "stdlib.h" 
#include "PSoCGPIOINT.h"

#define RESOLUTION 8                      // ADC resolution
#define SCALE_BG  (( 1 << RESOLUTION)/55) // BarGraph scale factor

BYTE i = 0;

void globalint1(void)
{
	if (i<254){
		i+=25;
		Counter16_1_Start();
	}
}

void vr1(void)
{
	if (i < 250) {
		Counter16_1_Stop();
	}
}

void main(void)
{
	BYTE bgPos;                          // BarGraph position  
	LCD_1_Start();                      
	LCD_1_Position(0,3);              
	LCD_1_PrCString("17.10.2012");
	LCD_1_InitBG(LCD_1_SOLID_BG); 
	             
	
	M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts дай мені
	M8C_EnableIntMask(INT_MSK0, INT_MSK0_GPIO);
	
	Counter16_1_EnableInt();
	DAC8_1_Start(DAC8_1_HIGHPOWER);
	Counter16_1_Start();
	
	while (1)
	{
		LCD_1_Position(1,0); 
		LCD_1_PrHexInt(i);
	  	bgPos = (BYTE)(i/SCALE_BG);
      	LCD_1_DrawBG(1, 0, 16, bgPos);
		DAC8_1_WriteBlind(i);
	}
}
