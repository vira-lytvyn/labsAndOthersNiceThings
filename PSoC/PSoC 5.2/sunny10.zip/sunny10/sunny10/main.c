//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules
#include <stdlib.h>

#define RREF 13000;

int iV0;
int iV1;
int iV2;
long lRvalue;
char pTemp[12];

void CalculateR(void);
void main(void)
{
	InputAtten_Start(InputAtten_HIGHPOWER);
	InputAtten_GAIN_CR2 |= 0x18;	//connect REFLO to analog column 0
	Buffer_Start(Buffer_HIGHPOWER);
	Buffer_GAIN_CR2 |= 0x1c;		//connect REFHI to analog column 1
	
	LCD_Start();
	LCD_Position(0, 0);
	LCD_PrCString("Laboratorna 10");
	
	ADC_Start(ADC_HIGHPOWER);
	M8C_EnableGInt;
	
	while (1) {
		ADCMUX_InputSelect(ADCMUX_PORT0_5);
		ADC_GetSamples(1);
		while(ADC_fIsDataAvailable() == 0);
		iV0 = ADC_iClearFlagGetData();
		
		ADCMUX_InputSelect(ADCMUX_PORT0_1);
		ADC_GetSamples(1);
		while(ADC_fIsDataAvailable() == 0);
		iV1 = ADC_iClearFlagGetData();
		
		ADCMUX_InputSelect(ADCMUX_PORT0_3);
		ADC_GetSamples(1);
		while(ADC_fIsDataAvailable() == 0);
		iV2 = ADC_iClearFlagGetData();
		
		CalculateR();
		LCD_Position(1, 0);
		LCD_PrCString("R = ");
		LCD_Position(1, 4);
		ltoa(pTemp, lRvalue, 10);
		LCD_PrString(pTemp);
	}
}


void CalculateR(void) {
	if (iV0 <= iV1) {
		lRvalue = -1;
	} else if (iV1 <= iV2) {
		lRvalue = 0;
	} else {
		lRvalue = RREF;
		lRvalue *= (long)(iV1 - iV2);
		lRvalue += ((long)((iV0 - iV1) > 1));
		lRvalue /= (long)(iV0 - iV1);
	}
}