//----------------------------------------------------------------------------
// C main line
//----------------------------------------------------------------------------

#include <m8c.h>        // part specific constants and macros
#include "PSoCAPI.h"    // PSoC API definitions for all User Modules


void main(void)
{
	// M8C_EnableGInt ; // Uncomment this line to enable Global Interrupts

	LCD_1_Start();                    // Initialize LCD hardware  
	/*LCD_1_InitBG(0); 
	LCD_1_DrawBG(0, 0, 16, 72);*/
	LCD_1_InitVBG();
	LCD_1_DrawVBG(1, 3, 2, 12);

	
	
// 	Zavdannay 4 - Vyvid dijsnoho chysla	
/*
//BYTE tz = 25;
	//char kr[] = ".";
	//BYTE di = 34;
LCD_1_Position(1,2);  // Position cursor @ row 1, col 2
LCD_1_PrHexInt(tz);
LCD_1_Position(1,3);
LCD_1_PrString(kr);
LCD_1_Position(1,4);
LCD_1_PrHexInt(di);*/
	
// Zavdannay 3 - Vyvid dvobajtnoho chysla		
	/*INT dva = 1993;						// Define byte symbol
	LCD_1_Start();                    // Initialize LCD hardware  
	LCD_1_Position(0,3);              // Position cursor @ row 0, col 3  
	LCD_1_PrCString("23.09.2012");    // Vyvid tekstu
	LCD_1_Position(1,4);              // Position cursor @ row 0, col 3  
	LCD_1_PrHexInt(dva);*/			  // Vyvid dvobajtnoho chysla
	
// Zavdannay 2 - Vyvid odnobajtnoho chysla	
	/*BYTE od = 45;						// Define byte symbol
	LCD_1_Start();                    // Initialize LCD hardware  
	LCD_1_Position(0,3);              // Position cursor @ row 0, col 3  
	LCD_1_PrCString("23.09.2012");    // Vyvid tekstu
	LCD_1_Position(1,4);              // Position cursor @ row 0, col 3  
	LCD_1_PrHexByte(od);*/			  // Vyvid odnobajtnoho chysla
		
// Zavdannay 1 - Vyvid String
	/*char str[ ] = "Laborat 1 Vira";    // Define "RAM" based string  
	LCD_1_Start();                    // Initialize LCD hardware  
	LCD_1_Position(0,3);              // Position cursor @ row 0, col 3  
	LCD_1_PrCString("23.09.2012");      // Vyvid tekstu  
	LCD_1_Position(1,0);              // Position cursor @ row 1, col 0  
	LCD_1_PrString(str); */             // Print "RAM" based string.  
 
	while(1)
	{
	};

	
	// Insert your main routine code here.
}
