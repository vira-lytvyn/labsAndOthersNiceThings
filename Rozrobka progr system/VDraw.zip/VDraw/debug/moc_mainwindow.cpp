/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created: Sat 12. Jan 23:11:21 2013
**      by: The Qt Meta Object Compiler version 62 (Qt 4.7.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../mainwindow.h"
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 62
#error "This file was generated using the moc from 4.7.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
static const uint qt_meta_data_MainWindow[] = {

 // content:
       5,       // revision
       0,       // classname
       0,    0, // classinfo
      15,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: signature, parameters, type, tag, flags
      12,   11,   11,   11, 0x08,
      26,   11,   11,   11, 0x08,
      46,   11,   11,   11, 0x08,
      60,   11,   11,   11, 0x08,
      76,   11,   11,   11, 0x08,
      93,   11,   11,   11, 0x08,
     102,   11,   11,   11, 0x08,
     118,  112,   11,   11, 0x08,
     142,  136,   11,   11, 0x08,
     163,   11,   11,   11, 0x08,
     178,   11,   11,   11, 0x08,
     193,   11,   11,   11, 0x08,
     205,   11,   11,   11, 0x08,
     215,   11,   11,   11, 0x08,
     228,   11,   11,   11, 0x08,

       0        // eod
};

static const char qt_meta_stringdata_MainWindow[] = {
    "MainWindow\0\0setLineType()\0setBrokenLineType()\0"
    "setRectType()\0setCircleType()\0"
    "setEllipseType()\0zoomIn()\0zoomOut()\0"
    "index\0setLineStyle(int)\0width\0"
    "setLineWidth(double)\0setFillColor()\0"
    "setLineColor()\0saveToSVG()\0openSVG()\0"
    "clearField()\0beginTest()\0"
};

const QMetaObject MainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_MainWindow,
      qt_meta_data_MainWindow, 0 }
};

#ifdef Q_NO_DATA_RELOCATION
const QMetaObject &MainWindow::getStaticMetaObject() { return staticMetaObject; }
#endif //Q_NO_DATA_RELOCATION

const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->metaObject : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow))
        return static_cast<void*>(const_cast< MainWindow*>(this));
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        switch (_id) {
        case 0: setLineType(); break;
        case 1: setBrokenLineType(); break;
        case 2: setRectType(); break;
        case 3: setCircleType(); break;
        case 4: setEllipseType(); break;
        case 5: zoomIn(); break;
        case 6: zoomOut(); break;
        case 7: setLineStyle((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 8: setLineWidth((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 9: setFillColor(); break;
        case 10: setLineColor(); break;
        case 11: saveToSVG(); break;
        case 12: openSVG(); break;
        case 13: clearField(); break;
        case 14: beginTest(); break;
        default: ;
        }
        _id -= 15;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
